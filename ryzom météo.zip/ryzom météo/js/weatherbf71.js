
$(function () {
  "use strict";
  //display_weather($('#flot-weather-graph'), $('#flot-weather-legend'), 'v1');
  display_weather($('#flot-weather-graph-v2'), $('#flot-weather-legend-v2'), 'v2');
  // toggle button, save state in local storage
  $("#weather-graph-button").click(function() {
    var $div = $('#weather-graph');
    $div.toggle();

    if (window.localStorage) {
      window.localStorage.setItem('weatherGraphVisible', $div.is(':visible') ? 'true' : 'false');
    }
  });

});

function display_weather($div, $legend, algo) {
  "use strict";

  var plot;
  var wsToDisplay = 8;
  var wsToDownload = 12;

  var url = 'https://ballisticmystix.net/atys/weather/?next=' + wsToDownload + '&last=1&algo=' + algo;

  //var $div = $('#flot-weather-graph');
  //var $legend = $('#flot-weather-legend');
  $legend.click(function (e) {
    var cont = $(e.target).data('continent');
    console.log(cont, e.target);
    if (cont) {
      toggleLine(cont);
      if (isLineVisible(cont)) {
        $(e.target).removeClass('disabled');
      }else{
        $(e.target).addClass('disabled');
      }
    }
  });
  $('<div id="tooltip"></div>').css({position: 'absolute', display: 'none'}).appendTo('body');
  function interpolateContinentWeather(hour, series) {
    var j;
    for (j = 0; j < series.data.length; ++j) {
      if (series.data[j][0] > hour) {
        break;
      }
    }
    var y, p1 = series.data[j - 1], p2 = series.data[j];
    if (p1 == null) {
      y = p2[1];
    } else if (p2 == null) {
      y = p1[1];
    } else {
      y = p1[1] + (p2[1] - p1[1]) * (hour - p1[0]) / (p2[0] - p1[0]);
    }
    //var o = plot.pointOffset({x: hour, y: y});
    //console.log('>> hour', hour, 'series', series, ', p1', p1, ', p2', p2, ', x:', hour, 'y:', y);
    return y.toFixed(3);
  }

  var weatherGraph = {};
  // restore graph from local storage
  if (window.localStorage) {
    var json = window.localStorage.getItem('weatherGraph');
    if (json) {
      try {
        weatherGraph = JSON.parse(json);
      } catch (e) {
        weatherGraph = {};
      }
    }
    var v = window.localStorage.getItem('weatherGraphVisible');
    if (v && v == 'true') {
      $('#weather-graph').show();
    }
  }

  function isLineVisible(continent) {
    if (!weatherGraph[continent]) {
      weatherGraph[continent] = {visible: true};
    }

    return weatherGraph[continent].visible;
  }

  function toggleLine(continent) {
    weatherGraph[continent].visible = !weatherGraph[continent].visible;
    if (window.localStorage) {
      localStorage.setItem('weatherGraph', JSON.stringify(weatherGraph));
    }

    var data = plot.getData();
    for (var i = 0; i < data.length; i++) {
      if (data[i].continent == continent) {
        data[i].lines.show = isLineVisible(continent);
        plot.setData(data);
        plot.draw();
        return;
      }
    }
  }

  function getWeatherCondition(value) {
    for (var i = 0; i < weatherConditions.length; ++i) {
      if (weatherConditions[i][0] > value) {
        return weatherConditions[i - 1][1];
      }
    }
    return weatherConditions[weatherConditions.length - 1][1];
  }

  //var plot;
  var dataSeries = [];
  var weatherConditions = [
    [0.00, "Excellent - 0%"],
    [0.16, "Bon - 16.7%"],
    [0.33, "Bon - 33.4%"],
    [0.49, "Mauvais - 50.0%"],
    [0.66, "Mauvais - 66.6%"],
    [0.83, "Médiocre - 83.4%"]
  ];
  var options = {
    yaxis: {
      min: 0,
      max: 1,
      ticks: weatherConditions
    },
    xaxis: {
      tickSize: 1,
      tickFormatter: function (val, axis) {
        //var hour = (val * 3) % 24;
        var hour = val % 24;
        return hour + 'h';
      }
    },
    legend: {
      hideable: true,
      show: true,
      noColumns: 5,
      container: $legend,
      labelFormatter: function (label, series) {
        var className = "tt";
        if (!series.lines.show) {
          className += " disabled";
           
        }
        var weather = interpolateContinentWeather(dataSeries.hour, series);
        var condition = getWeatherCondition(weather);
        var tooltip = '&nbsp;' + label + ': ' + condition + ' (' + weather + ')';
        //console.log("labelFormatter:", series);
        return '<span class="' + className + '" data-caption="' + label + '" data-tooltip="' + tooltip + '" data-continent="' + series.continent + '">' + label + '</span>';
      }
    },
    grid: {
      markings: function (axes) {
        var x, hour, isNight = false, markings = [];
          
        // night areas
        for (x = Math.floor(axes.xaxis.min); x < axes.xaxis.max; x++) {
          hour = x % 24;
          if (!isNight && hour >= 22 || hour < 3) {
            markings.push({
              xaxis: {
                from: x,
                to: x + (hour == 22 ? 5 : 3 - hour )
              },
              color: '#B6B6B4'
              
            });
            isNight = true;
          } else if (hour < 22 || hour >= 3) {
            isNight = false;
          }
        }

        // current hour
        hour = dataSeries.hour;
        markings.push(
            {
              xaxis: {from: hour, to: hour},
              yaxis: {from: 0, to: 1},
              color: '#C11B17',
              lineWidth: 3
              
            }
        );

        return markings;
      }
    },
    series: {
      lines: {
        show: true
      }
    }
  };

  var regionNames = {
    tryker: 'Tryker',
    matis: 'Matis',
    fyros: 'Fyros',
    zorai: 'Zoraï',
    //
    nexus: 'Nexus',
    sources: 'Sources Interdites',
    bagne: 'Gouffre d°Ichor',
    terre: 'Terre Abandonnées',
    route_gouffre: 'Route des Ombres'
  };

  function translate(c) {
    return regionNames[c] ? regionNames[c] : c;
  }

  function updateGraph() {
    var plotData = [];
    for (var continent in dataSeries.continents) {
      if (dataSeries.continents.hasOwnProperty(continent)) {
        if ($.inArray(continent, ['newbieland', 'kitiniere', 'matis_island']) !== -1) {
          continue;
        }
        var showLine = isLineVisible(continent);
        var series = {
          continent: continent,
          label: translate(continent),
          data: [],
          lines: {show: showLine},
          points: {show: false}
        };
        for (var cycle in dataSeries.continents[continent]) {
          if (dataSeries.continents[continent].hasOwnProperty(cycle)) {
            var record = dataSeries.continents[continent][cycle];
            var c = parseInt(record.cycle) * 3;
            var v = parseFloat(record.value);

            series.data.push([c, v]);
            series.data.push([c + 1, v]);
            series.data.push([c + 2, v]);
          }
        }
        plotData.push(series);
      }
    }

    options.xaxis.min = dataSeries.hour - 2;
    options.xaxis.max = options.xaxis.min + wsToDisplay * 3;
    plot = $.plot($div, plotData, options);
  }

  var nextUpdate = 0;
  var igHourUpdate = 0;
  var dlReady = false;

  function fetchWeather() {
    if (--nextUpdate > 0) {
      if (dlReady && ++igHourUpdate >= 3) {
        dataSeries.hour += (1 / 60) * igHourUpdate / 3;
        updateGraph();

        igHourUpdate = 0;
      }
      //console.debug('>>', {nextUpdate: nextUpdate, igHourCounter: igHourCounter});
      return;
    }

    //console.debug('>> fetchWeather');
    dlReady = false;
    $.getJSON(url, {}, function (json) {
      if (json.result) {
        dataSeries = json.result;

        // we have extra cycles, so we can wait longer between updates
        nextUpdate = 9 * 60 * (wsToDownload - wsToDisplay);
        igHourUpdate = 0;

        updateGraph();
      } else {
        nextUpdate = 30;
      }
      dlReady = true;
    });
  }

  // update graph every 3 min
  setInterval(fetchWeather, 1000);
  fetchWeather();
}

