$(function () {
  var url = '?p=atys_calendar';

  function updateCalendar(data) {
    console.debug('>> updateCalendar', data);
    for (var index in data) {
      if (data.hasOwnProperty(index)) {
        var $elm = $('#atys-calendar-' + index);
        if (index.slice(index.length - 9) == '-progress') {
          $elm.css('width', data[index] + '%');
          console.debug('>> set width', index, data[index]);
        } else {
          $elm.html(data[index]);
          console.debug('>> set content', index, data[index]);
        }
      }
    }
  }

  function fetchCalendar() {
    $.getJSON(url, {}, function (json) {
      if (json.result) {
        updateCalendar(json.result);
      } else {
        nextUpdate = 30;
      }
      dlReady = true;
    });
  }

  // initial calendar is already drawn, so no need to call this
  setInterval(fetchCalendar, 60000);
});
