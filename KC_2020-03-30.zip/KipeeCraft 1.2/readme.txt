KipeeCraft is a crafting simulator, material database, recipe generator and organizer.

Crafting works similar to the ingame system. Just click on an empty field 
to add materials. Some recipe examples are already included.
You can access all functions with the menu, here are some of the shortcuts:

F2 - Save
F3 - Load
F7 - Database
F10 - Clear Recipe

KipeeCraft is fully modular, you can for example use the Database and create a Recipe simultaniously.

Arcueid, 2020